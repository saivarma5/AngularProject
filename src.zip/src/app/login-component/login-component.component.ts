import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule,
  FormsModule,
  FormGroup,
  FormControl,
  Validators,
  FormBuilder } from '@angular/forms';



@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.css']
})
export class LoginComponentComponent implements OnInit {
  
myform: FormGroup;
email:FormControl;
password:FormControl;

  constructor() {
   
   }

   ngOnInit() {
    this.createFormControls();
     this.createForm();
  }
  createFormControls() {
  
    this.email = new FormControl("", [
      Validators.required,
      Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')
      
    ]);
    this.password = new FormControl("", [
      Validators.minLength(8),
      Validators.required
      
    ]);
    }
  
    createForm() {
    this.myform = new FormGroup({
     
      Email: this.email,
      Password: this.password,

    });
  }

  account_validation_messages = {

'email': [
  { type: 'required', message: 'Email is required' },
  { type: 'pattern', message: 'Enter a valid email' }
],
'password': [
  { type: 'required', message: 'Password is required' },
  { type: 'minlength', message: 'Password must be at least 8 characters long' },

],
     }

    onSubmit() {
      if(this.myform.valid){
      if(this.myform.get("Email").value=="saivarma@gmail.com" && this.myform.get("Password").value=="saivarma" ){
        alert("login succesful "+this.myform.get("Email").value);
      }
        else if(this.myform.get("Email").value!="saivarma@gmail.com" ){
     alert("Incorrect  email, please enter valid email");
    }
      else if(this.myform.get("Email").value=="saivarma@gmail.com" &&this.myform.get("Password").value!="saivarma"){
      alert("Incorrect  password, please enter valid password");
    }
      }
  
 
  }

  
}
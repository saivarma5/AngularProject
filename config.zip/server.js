const bodyParser = require('body-parser');
const express = require('express');
const fs = require('fs');
mongo = require('./custom_modules/mongo_util/mongoConnection')
const cors = require('cors');
var session = require('express-session');
var http = require('http')
var path = require('path')
var configObject = require('./config.json');
var db;

mongo.connect(configObject.mongo_db_url,configObject.mongo_db_name);
var mongoFindOne = require("./custom_modules/mongo_util/findOneMongo");
var mongoFindAll = require("./custom_modules/mongo_util/findAllMongo");
var mongoFindOneAndUpdate = require("./custom_modules/mongo_util/findOneAndUpdateMongo");
var mongoInsertAll = require("./custom_modules/mongo_util/insertAllMongo");
const app = express();

// all environments
app.set('port', process.env.PORT || configObject.app_Port);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}))

var server = http.createServer(app);
server.listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
  //server.on('error', onError);
});

app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'POST');
  next();
});

app.get('/servicecatalog', (req,res) => {
    mongoFindOne.findOne('services', {name:"catalog"} ,'' ,function(err, result) {
        if(err){
          console.log("get service catalog Err  "+ err);
          res.send(err); 
        }
        console.log("result============>  "+ result);
        console.log(result.json);
        res.send(result.json);
        
      });
});


app.post('/servicecatalog', (req, res) => {
  mongoFindOneAndUpdate.findOneAndUpdate('services', {name:"catalog"} , { $set: { json: req.body } }, { sort: {name: 1}, returnNewDocument: true }, function(err, result) {
    if(err){
      console.log("post service catalog Err  "+ err);
      res.send(err); 
    }
    console.log("catalog post result============>  ", result);
    console.log(result.value.json);
    res.send(result.value.json);
    
  });
});

app.get('/servicelist', (req,res) => {
    mongoFindOne.findOne('services', {name:"catalog"} ,'' ,function(err, result) {
        if(err){
          console.log("get service list Err  "+ err);
          res.send(err); 
        }
        console.log("service list result============>  ", result);
        console.log(result.json);
        res.send(result.json);   
      });
});

app.post('/serviceControls', (req,res) => {
    console.log('get service ctrl: ', req.body.servicename);
    mongoFindOne.findOne('services', {  name:req.body.servicename } ,'' ,function(err, result) {
        if(err){
            console.log("get service controls Err  "+ err);
            res.send({ status: 400, value: "No record"}); 
        } else {
            console.log("service controls result============>  ", result);
            res.send({ status: 200, value: result.json}); 
        }
      });
});

app.post('/saveservicecontrol', (req, res) => {
    console.log('Received save service control request');

    mongoFindOneAndUpdate.findOneAndUpdate('services', {name: req.body.service} , { $set: { json: req.body.controlmodel } }, 
            { sort: {name: 1}, upsert:true, returnNewDocument : true }, function(err, result) {
      if(err){
        console.log("post service catalog Err  "+ err);
        res.send({ status: 400, value: "Error occurred while saving"}); 
      } else {
        console.log("catalog post result============>  ", result);
        res.send({ status: 200, value: result});
      }
    });
});


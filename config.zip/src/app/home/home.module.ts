import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileUploadModule, FileSelectDirective, FileUploader } from 'ng2-file-upload';
import { HomeComponent } from './home.component';
import { MatFormFieldModule, MatCardModule, MatButtonModule, MatSelectModule, MatAutocompleteModule, MatButtonToggleModule, MatCheckboxModule, MatChipsModule, MatDatepickerModule, MatDialogModule, MatExpansionModule, MatGridListModule, MatIconModule, MatListModule, MatMenuModule, MatNativeDateModule, MatProgressBarModule, MatProgressSpinnerModule, MatRadioModule, MatRippleModule, MatSidenavModule, MatSliderModule, MatSlideToggleModule, MatSnackBarModule, MatStepperModule, MatTableModule, MatTabsModule, MatToolbarModule, MatTooltipModule } from '@angular/material';
import {MatInputModule} from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AmexioChartsModule, AmexioDashBoardModule, AmexioEnterpriseModule, AmexioMapModule, AmexioDataModule, IconLoaderService, AmexioWidgetModule } from 'amexio-ng-extensions';
import { TreeviewModule } from 'ngx-treeview';
import { TreeModule } from 'angular-tree-component';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    FileUploadModule, 
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCardModule,
    MatButtonModule,
    AmexioDataModule,
    AmexioChartsModule,AmexioDashBoardModule,AmexioEnterpriseModule,AmexioMapModule,
    AmexioWidgetModule,
    TreeviewModule.forRoot(),
    TreeModule.forRoot(),
    MatAutocompleteModule,
  MatButtonToggleModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule
  ],
  declarations: [HomeComponent],
  providers: [IconLoaderService]
})
export class HomeModule { }

import { Component, OnInit, NgZone, ViewChild } from '@angular/core';
import { FileUploader,FileUploadModule   } from 'ng2-file-upload';
import {CdkTextareaAutosize} from '@angular/cdk/text-field';
import {take} from 'rxjs/operators';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { IconLoaderService } from 'amexio-ng-extensions';
import { TreeviewItem, TreeviewComponent, TreeviewHelper, TreeviewConfig } from 'ngx-treeview';
import { TREE_ACTIONS, KEYS, ITreeOptions, IActionMapping, TreeModel, TreeNode, TreeComponent } from 'angular-tree-component';

// const URL = '/api/';
const URL = 'https://evening-anchorage-3159.herokuapp.com/api/';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  
  themeOptions: any[];
  selectedTheme: string;

  constructor(private ngZone: NgZone, private formBuilder: FormBuilder) {

    this.themeOptions = ['Bootstrap', 'Angular Material'];

  }

  ngOnInit(): void {
    
  }

  @ViewChild('autosize') autosize: CdkTextareaAutosize;

  triggerResize() {
    // Wait for changes to be applied, then trigger textarea resize.
    this.ngZone.onStable.pipe(take(1))
        .subscribe(() => this.autosize.resizeToFitContent(true));
  }
  public uploader:FileUploader = new FileUploader({url: URL});
  public hasBaseDropZoneOver:boolean = false;

  public fileOverBase(e:any):void {
    this.hasBaseDropZoneOver = e;
  }


}

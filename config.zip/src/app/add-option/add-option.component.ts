import { Component, OnInit, Inject, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-add-option',
  templateUrl: './add-option.component.html',
  styleUrls: ['./add-option.component.css']
})
export class AddOptionComponent implements OnInit {

  @Output() serviceName: string = 'Cancel';
  serviceInputName: string;
  nodeType: string;
  action: string;
  //editValue: string;

  constructor(private dialogRef: MatDialogRef<AddOptionComponent>,
    @Inject(MAT_DIALOG_DATA) data) { 
      this.nodeType = data.type;
      this.action = data.action;
      if(this.action === 'Edit'){
        this.serviceInputName = data.editValue;
      }
      //this.dialogRef.updatePosition({ top: '50px', left: '350px', bottom: '0px' }).updateSize('600px', '600px');
      this.dialogRef.updateSize('800px', '800px');
    }

  ngOnInit() {
  }

  save(option: string){
    console.log('serviceinputname: '+this.serviceInputName);
    if(option === 'save'){
      this.serviceName = this.serviceInputName;
    }
    this.dialogRef.close(this.serviceName);
  }
}

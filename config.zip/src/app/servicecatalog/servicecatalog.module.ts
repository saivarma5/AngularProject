import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServicecatalogComponent } from './servicecatalog.component';
import { TreeModule } from 'angular-tree-component';
import { MatCardModule, MatDialogModule, MatInputModule, MatButtonModule } from '@angular/material';
import { AddOptionComponent } from '../add-option/add-option.component';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatInputModule,
    MatCardModule,
    MatDialogModule,
    MatButtonModule,
    TreeModule.forRoot()
  ],
  declarations: [ServicecatalogComponent]
})
export class ServicecatalogModule { }

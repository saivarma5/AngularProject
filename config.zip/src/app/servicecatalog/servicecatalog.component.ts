import { Component, OnInit, ViewChild } from '@angular/core';
import { TreeModel, TreeNode, TREE_ACTIONS, ITreeOptions, TreeComponent } from 'angular-tree-component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { AddOptionComponent } from '../add-option/add-option.component';
import { ProductService } from '../product.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-servicecatalog',
  templateUrl: './servicecatalog.component.html',
  styleUrls: ['./servicecatalog.component.css']
})
export class ServicecatalogComponent implements OnInit {

  @ViewChild(TreeComponent)
  private tree: TreeComponent;
  
  private catalogUrl = 'assets/servicecatalog.json';

  constructor(public dialog: MatDialog, public _productService: ProductService,
              public snackbar: MatSnackBar) { 
    
  }

  ngAfterViewInit(){
    // change logic to get array from DB
    this._productService.getServiceCatalog().subscribe(
      (result) => {
        console.log("In TS file: ",result);
        this.nodes = result;
      });
  }

  ngOnInit() {
  }

  treenode: TreeNode;
  nodeName : string;
  contextMenu: {node: TreeNode, x: number, y: number} = null;
  sourceNode: TreeNode = null;
  editNode: TreeNode = null;
  doCut = false;
  nodes = [];

  options: ITreeOptions = {
    actionMapping: {
      mouse: {
        contextMenu: (treeModel: TreeModel, treeNode: TreeNode, e: MouseEvent) => {
          e.preventDefault();
          if (this.contextMenu && treeNode === this.contextMenu.node) {
            return this.closeMenu();
          }
          this.contextMenu = {
            node: treeNode,
            x: e.pageX + 50,
            y: e.pageY - 75
          };
        },
        click: (treeModel: TreeModel, treeNode: TreeNode, e: MouseEvent) => {
          this.closeMenu();
          TREE_ACTIONS.TOGGLE_ACTIVE(treeModel, treeNode, e);
        }
      }
    }
  };

  closeMenu = () => {
    this.contextMenu = null;
  }

  // Adding category to the tree - Level 1
  addCat() {
    let isLeaf = this.contextMenu.node.isLeaf;
    let contextNode = this.contextMenu.node;
    this.closeMenu();
    this.openDialog(isLeaf, contextNode, 'Add', 'Category', '');
  }

  // Adding service to the tree - Level 2
  addSer() {
    let isLeaf = this.contextMenu.node.isLeaf;
    let contextNode = this.contextMenu.node;
    this.closeMenu();
    this.openDialog(isLeaf, contextNode, 'Add', 'Service', '');
  }

  /* 
    @param isLeaf      - whether it is a leaf node.
    @param contextNode - the actual node being edited
    @param action      - Whether adding or editing a node (Add/Edit)
    @param nodeType    - Category (Level 1)/Service (Level 2)
    @param editValue   - used while editing, the existing value is passed
  */
  openDialog(isLeaf: boolean, contextNode: TreeNode, action: string, 
    nodeType: string, editValue: string) {
    const dialogConfig = new MatDialogConfig();
    let type = 'root';

    dialogConfig.disableClose = true;
    dialogConfig.minWidth = 400;
    dialogConfig.data = { 
      type: nodeType, 
      action: action,
      editValue: editValue
    }
    let dialogRef = this.dialog.open(AddOptionComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {

      if(result === 'Cancel'){
        return;
      }
      
      if(action === 'Edit'){
        let nodeName = this.nodes[0].children[contextNode.index].name;
        if(isLeaf){
          this.nodes[0].children[contextNode.parent.index].children[contextNode.index].name = result;
        } else{
          this.nodes[0].children[contextNode.index].name = result;
        }
        

      } else{
        if(nodeType === 'Category'){
          this.nodes[0].children.push({ name: result, children: [] });
        } else {
          this.nodes[0].children[contextNode.index].children.push({ name: result});
        }
      }
      this.tree.treeModel.update();
    });
  }
  
  openDialog1() {
    const dialogConfig = new MatDialogConfig();
    let type = 'root';

    dialogConfig.disableClose = true;
    dialogConfig.minWidth = 400;
    dialogConfig.data = { 
     
    }
    let dialogRef = this.dialog.open(AddOptionComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {

      if(result === 'Cancel'){
        return;
      }
      
     
    });
  }

  editNodeName(editValue: string){
    let isLeaf = this.contextMenu.node.isLeaf;
    let contextNode = this.contextMenu.node;
    this.closeMenu();
    this.openDialog(isLeaf, contextNode, 'Edit', '', editValue);
  }

  delete(){
    let contextNode = this.contextMenu.node;

    this.closeMenu();

    let nodeIndex = contextNode.index;
    let nodeParentIndex = contextNode.parent.index;
    let isRootParent = contextNode.parent.isRoot;

    if(isRootParent){
      this.nodes[0].children.splice(nodeIndex, 1);
    } else {
      this.nodes[0].children[nodeParentIndex].children.splice(nodeIndex, 1);
    }
    
    this.tree.treeModel.update();
  }

  saveCatalog(){
    this._productService.saveServiceCatalog(this.nodes).subscribe((result) => {
        console.log("POST call successful value returned in body", result);
        this.snackbar.open("Catalog Saved successfully",'',{duration: 1000});
      }, (err) => {
      console.log(err);
      }); ;

  }

  /* edit = () => {
    console.log('edit: '+this.contextMenu.node.treeModel);
    this.editNode = this.contextMenu.node;
    this.closeMenu();
    //let nodeName = this.nodes[0].children[this.editNode.index].name;
    //this.nodes[0].children[this.editNode.index].name.replace(nodeName, )
  }

  stopEdit = () => {
    this.editNode = null;
  }

  copy = () => {
    this.sourceNode = this.contextMenu.node;
    this.doCut = false;
    this.closeMenu();
  }

  cut = () => {
    this.sourceNode = this.contextMenu.node;
    this.doCut = true;
    this.closeMenu();
  }

  paste = () => {
    if (!this.canPaste()) {
      return;
    }
    this.doCut
      ? this.sourceNode.treeModel.moveNode(this.sourceNode, { parent: this.contextMenu.node, index: 0 })
      : this.sourceNode.treeModel.copyNode(this.sourceNode, { parent: this.contextMenu.node, index: 0 });

    this.sourceNode = null;
    this.closeMenu();
  }

  canPaste = () => {
    if (!this.sourceNode) {
      return false;
    }
    return this.sourceNode.treeModel.canMoveNode(this.sourceNode, { parent: this.contextMenu.node, index: 0 });
  } */

}

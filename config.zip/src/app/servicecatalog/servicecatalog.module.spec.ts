import { ServicecatalogModule } from './servicecatalog.module';

describe('ServicecatalogModule', () => {
  let servicecatalogModule: ServicecatalogModule;

  beforeEach(() => {
    servicecatalogModule = new ServicecatalogModule();
  });

  it('should create an instance', () => {
    expect(servicecatalogModule).toBeTruthy();
  });
});

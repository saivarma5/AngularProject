import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AlertComponent } from './alert.component';
import { MatButtonModule, MatToolbarModule, MatFormFieldModule, MatInputModule, MatCardModule, MatListModule, MatDialogModule, MatSelectModule, MatAutocompleteModule, MatButtonToggleModule, MatCheckboxModule, MatChipsModule, MatDatepickerModule, MatExpansionModule, MatGridListModule, MatIconModule, MatMenuModule, MatNativeDateModule, MatProgressBarModule, MatProgressSpinnerModule, MatRadioModule, MatRippleModule, MatSliderModule, MatSlideToggleModule, MatSnackBarModule, MatStepperModule, MatTableModule, MatTabsModule, MatTooltipModule } from '@angular/material';
import { HomeModule } from './home/home.module';
import { MatSidenavModule } from '@angular/material/sidenav';
import { HomeComponent } from './home/home.component';
import { ServicecatalogComponent } from './servicecatalog/servicecatalog.component';
import { ServicepageComponent } from './servicepage/servicepage.component';
import { ServicecatalogModule } from './servicecatalog/servicecatalog.module';
//import { TreeModule } from 'ng2-tree';
import { TreeModule } from 'angular-tree-component';
//Dashboard,Charts & Maps are available as seperate module (not in AmexioWidgetModule)
import {AmexioChartsModule,AmexioDashBoardModule,AmexioEnterpriseModule,AmexioMapModule, IconLoaderService, AmexioWidgetModule, AmexioDataModule} from 'amexio-ng-extensions';
import { TreeviewModule } from 'ngx-treeview';
import { AddOptionComponent } from './add-option/add-option.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AlertComponent,
    ServicepageComponent,
    AddOptionComponent       
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'homepage', component: HomeComponent},
      { path: 'servicecatalog', component: ServicecatalogComponent},
      { path: 'servicepage', component: ServicepageComponent},
      { path: '', redirectTo: 'homepage', pathMatch: 'full'},
      { path: '**', redirectTo: 'homepage', pathMatch: 'full'}
  ]),
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    HomeModule,
    ServicecatalogModule,
    MatSidenavModule,
    MatToolbarModule,
    MatInputModule,
    MatFormFieldModule,
    MatCardModule,
    MatListModule,
    MatDialogModule,
    MatSelectModule,
    MatAutocompleteModule,
  MatButtonToggleModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatMenuModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTableModule,
  MatTabsModule,
  MatTooltipModule,
    //TreeModule,
    AmexioChartsModule,AmexioDashBoardModule,AmexioEnterpriseModule,AmexioMapModule,
    AmexioWidgetModule,
    AmexioDataModule,
    TreeviewModule.forRoot(),
    TreeModule.forRoot()
  ],
  exports: [
    MatListModule
  ],
  providers: [IconLoaderService],
  bootstrap: [AppComponent],
  entryComponents: [AlertComponent, AddOptionComponent]
})
export class AppModule { }

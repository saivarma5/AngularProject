import { Component, Injector } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { AlertComponent } from './alert.component';
import { DomSanitizer } from '@angular/platform-browser';
import {FormBuilder, FormGroup} from '@angular/forms';
import { IconLoaderService } from 'amexio-ng-extensions';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private iconService : IconLoaderService){
    this.iconService.iconToUse = 'fa';
  }
  links = [{
    label : "Home Page",
    routerLink: "/homepage"
  },
  {
    label: "Service Catalog",
    routerLink: "/servicecatalog"
  },
  {
    label: "Service Page Creation",
    routerLink: "/servicepage"
  }];

 /*  content = null;
  message = "<my-alert message=".concat("Hi How are you!!!", ">", "<mat-checkbox>Check me!</mat-checkbox>", "</my-alert>");
  constructor(private injector: Injector, private domSanitizer: DomSanitizer){
    const AlertElement = createCustomElement(AlertComponent, {injector: this.injector});
    customElements.define('my-alert', AlertElement);
    setTimeout(() => {
      this.content = this.domSanitizer.bypassSecurityTrustHtml(this.message);
    }, 1000);
  }

  ngDoBootstrap(){
    
  } */

  /* options: FormGroup;

  constructor(fb: FormBuilder) {
    this.options = fb.group({
      bottom: 0,
      fixed: false,
      top: 0
    });
  } */
}

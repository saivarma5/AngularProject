import { Injectable } from "@angular/core";
import { HttpClient, HttpErrorResponse, HttpParams } from "@angular/common/http";
import { throwError } from "rxjs/internal/observable/throwError";
import { Observable } from "rxjs/internal/Observable";
import { tap, catchError } from "rxjs/operators";


@Injectable({
    providedIn: 'root'
  })

  export class ProductService {
      
    constructor(private http: HttpClient) { }

    getServiceCatalog(): Observable<any> {
        return this.http.get<any>('http://localhost:3000/servicecatalog').pipe(
          tap(data => console.log('All: ' + JSON.stringify(data))),
          catchError(this.handleError)
        );
    }

    saveServiceCatalog(catalogJson: any[]) {
        console.log('catalogJson: '+catalogJson);
        return this.http.post<any>('http://localhost:3000/servicecatalog',catalogJson).pipe(
            tap((catalogJson) => console.log(`saved successfully`)),
            catchError(this.handleError)
          );
    }

    getServiceList(): Observable<any> {
        return this.http.get<any>('http://localhost:3000/servicelist').pipe(
          tap(data => console.log('All: ' + JSON.stringify(data))),
          catchError(this.handleError)
        );
    }

    getServiceControls(serviceName: string): Observable<any> {
        return this.http.post<any>('http://localhost:3000/serviceControls', {servicename: serviceName}).pipe(
          tap(data => console.log('All: ' + JSON.stringify(data))),
          catchError(this.handleError)
        );
    }
    
    saveServiceControl(controlModel: any[], selectedService: string) {
        return this.http.post<any>('http://localhost:3000/saveservicecontrol', { controlmodel: controlModel, service: selectedService}).pipe(
            tap((catalogJson) => console.log(`control model saved successfully`)),
            catchError(this.handleError)
          );
    }

    private handleError(err: HttpErrorResponse) {
        // in a real world app, we may send the server to some remote logging infrastructure
        // instead of just logging it to the console
        let errorMessage = '';
        if (err.error instanceof ErrorEvent) {
          // A client-side or network error occurred. Handle it accordingly.
          errorMessage = `An error occurred: ${err.error.message}`;
        } else {
          // The backend returned an unsuccessful response code.
          // The response body may contain clues as to what went wrong,
          errorMessage = `Server returned code: ${err.status}, error message is: ${err.message}`;
        }
        console.error(errorMessage);
        return throwError(errorMessage);
      }
  }
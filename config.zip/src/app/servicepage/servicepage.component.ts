import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormArray, Validators, FormGroup, FormControl } from '@angular/forms';
import { ProductService } from '../product.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-servicepage',
  templateUrl: './servicepage2.component.html',
  styleUrls: ['./servicepage.component.css']
})

export class ServicepageComponent implements OnInit {

  public exampleForm: FormGroup;
  controlTypeList: string[];
  requiredFieldList: string[];
  catalogGroups: any[] = [''];
  showControl: boolean;
  selectedService: string;
  editControl: boolean;
  enableSubmitButton: boolean;

  constructor(private fb: FormBuilder, public _productService: ProductService,
              public snackbar: MatSnackBar) {
    this.showControl = false;
    this.editControl = false;
    this.enableSubmitButton = false;
  }

  ngOnInit() {

    this._productService.getServiceList().subscribe(
      (result) => {
        this.catalogGroups = result;
      });

    this.controlTypeList = ['text', 'pass', 'email', 'radio', 'checkbox', 'date'];
    this.requiredFieldList = ['yes', 'no'];
  }

  public loadControls(option: any){
    let serviceValue = option.value;
    this._productService.getServiceControls(serviceValue).subscribe(
      (result) => {
        this.showControl = true;
        if(result.status == 200){
          this.exampleForm = this.fb.group({
            formUnits: this.retrieveControls(result.value.formUnits)
          });
          this.exampleForm.disable();
          this.editControl = false;
        } else {
          this.exampleForm = this.fb.group({
            formUnits: this.fb.array([
               this.getControls()
            ])
          });
          this.exampleForm.disable();
        }
      });
  }

  private retrieveControls(units: any[]): FormArray{
    this.exampleForm = this.fb.group({
      formUnits: this.fb.array([])
    })
    const control = <FormArray>this.exampleForm.controls['formUnits'];
    
    units.forEach(unit => {
      control.push(this.fb.group({
        label: [unit.label, Validators.required],
        controlType: [unit.controlType, Validators.required],
        requiredField: [unit.requiredField, Validators.required],
        options: [unit.options],
        placeholder: [unit.placeholder]
      }));
    })
    return control;
  }

  /**
   * Create form unit
   */
  private getControls() {
    // const numberPatern = '^[0-9.,]+$';
      return this.fb.group({
        label: ['', Validators.required],
        controlType: ['', Validators.required],
        requiredField: ['', Validators.required],
        options: [''],
        placeholder: ['']
      });    
  }

  /**
   * Add new unit row into form
   */
  private addFormUnit() {
    const control = <FormArray>this.exampleForm.controls['formUnits'];
    control.push(this.getControls());
  }

  /**
   * Remove unit row from form on click delete button
   */
  private removeFormUnit(i: number) {
    const control = <FormArray>this.exampleForm.controls['formUnits'];
    control.removeAt(i);
  }

  private editControls(isEdit: boolean){
    if(isEdit){
      this.editControl = true;
      this.exampleForm.enable();
    } else {
      this.editControl = false;
      this.exampleForm.disable();
    }
  }
  /**
   * Save form data
   */
  save(model: any, isValid: boolean, e: any) {
    e.preventDefault();
    alert('Form data are: '+JSON.stringify(model));
    this._productService.saveServiceControl(model, this.selectedService).subscribe((result) => {
      this.snackbar.open("Service Controls saved successfully",'',{duration: 1000});
      this.editControl = false;
      this.exampleForm.disable();
    }, (err) => {
      this.snackbar.open("Save not successfull. Please try again",'',{duration: 1000});
    });
  }

}

const { spawn } = require('child_process');

exports.executCommand = function (command,arguments,options,callback) {
	var error=false;
	var result='';
	var commandFired;
	
	if (!options && !arguments)
		commandFired = spawn(command);
	else if(!options)
		commandFired = spawn(command, arguments);
	else{
		commandFired = spawn(command, arguments, options);
	}
	
	commandFired.stdout.on('data', (data) => {
	  console.log(`stdout: ${data}`);
	  result +=data;
	});

	commandFired.stderr.on('data', (data) => {
	  console.log(`stderr: ${data}`);
	  error=true;
	  result +=data;
	});

	commandFired.on('close', (code) => {
	  console.log(`child process exited with code ${code}`);
	  callback(error,result);
	  error=false;
	  result='';
	});
};
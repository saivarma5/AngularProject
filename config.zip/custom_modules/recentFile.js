var fs = require("fs");
var path = require('path');
exports.getRecentFileName = function (dir, callback) {
    var newest = "";
	files = fs.readdirSync(dir);
	newest = files[0];
    for (i = 0; i < files.length; i++) {
		f1_time = fs.statSync(path.join(dir, files[i])).mtime.getTime();
		f2_time = fs.statSync(path.join(dir, newest)).mtime.getTime();
		if (f1_time > f2_time)
		{  
			newest= files[i]; 
		}
    }
       // newest=newest+"/HTML Results/Summary.html";
	    callback (path.join(dir, newest)); 
}
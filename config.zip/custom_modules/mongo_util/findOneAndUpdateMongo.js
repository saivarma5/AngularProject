var mongo = require('./mongoConnection');

//query variable contains json data used for querying the db

exports.findOneAndUpdate = function (collectionName, searchQuery, updateValue, options, callback) {
	//console.log("___dbname: "+collectionName+"___searchquery: "+JSON.stringify(searchQuery) +"___projectionQuery: "+JSON.stringify(projectionQuery));   
    mongo.collection(collectionName).findOneAndUpdate(searchQuery, updateValue, options , function(err, keyDoc) {
        if(err){
            callback(err, "DB connectivity failed while findAndModify");
        }
        if(keyDoc==null||keyDoc==""){
			callback("Data not exists",null);
		}
		else{
			//console.log(keyDoc)
			callback(null,keyDoc);
		}
    });
};

var mongo = require('./mongoConnection');

//query variable contains json data used for querying the db

exports.findAll = function (collectionName,searchQuery, projectionQuery, callback) {
	
	mongo.collection(collectionName).find(searchQuery, projectionQuery).batchSize(1000000000).toArray(function(err, keyDoc){
		if(err){
			callback(err,"DB connectivity failed");
		}
		if(keyDoc==null||keyDoc==""){
			callback("Data not exists",null);
		}
		else{
			callback(null,keyDoc);
		}
	});
};

var http = require('http');

exports.requestHttp = function (hostIp,port,type,url,callback) {
	var response='';
	console.log("____port : "+port+" : hostIp : " +hostIp+" : methodtype : "+type+" : pathurl : "+url);
	var params = {
			host: hostIp,
			port: port,
			path: url,
			method: type
	};
	console.log(params);
	var manualRequest=http.request(params, function(res) {
		console.log('STATUS: ' + res.statusCode);
		console.log('HEADERS: ' + JSON.stringify(res.headers));
		res.setEncoding('utf8');
		res.on('readable', function () {
		    var chunk = this.read() || '';
		    response  += chunk;
		    console.log('chunk: ' + Buffer.byteLength(chunk) + ' bytes');
		    });
//		res.on('data', function(chunk) {
//			console.log("resultJSON",chunk)
//			
//			response=chunk;
//			//callback(res.statusCode,chunk);
//		});
		res.on('end', function(){
			callback(res.statusCode, response);		  
			});
	});
	manualRequest.on('error', function(err) { 
		console.log("ERROR: " + err.message); 
		callback("501",err.message);

	});
	manualRequest.end();
};
var mongo = require('./mongoConnection');

//query variable contains json data used for querying the db in sorted way

exports.findAllLimitSort = function (collectionName,searchQuery,sortquery,limitQuery,callback) {
//    console.log("___dbname: "+collectionName+"___searchquery: "+searchQuery+"___sortquery: "+sortquery);
	mongo.collection(collectionName).find(searchQuery).limit(limitQuery).sort(sortquery).batchSize(1000000000).toArray(function(err, keyDoc){
		if(err){
			console.log(err);
			callback(err,"DB connectivity failed");
			}
		if(keyDoc==null||keyDoc==""){
			callback("Data not exists",null);
		}
		else{
			callback(null,keyDoc);
		}
	});
};
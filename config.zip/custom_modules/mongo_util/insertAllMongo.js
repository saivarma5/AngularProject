var mongo = require('./mongoConnection');

//query variable contains json data used for querying the db

exports.insert = function (collectionName,insertQuery,callback) {
	//console.log("___dbname: "+collectionName+"___searchquery: "+JSON.stringify(insertQuery));
	mongo.collection(collectionName).insertOne(insertQuery,function(err, keyDoc){
		if(err){
			//console.log(err);
			callback(err,"DB connectivity failed");
			}
		if(keyDoc==null||keyDoc==""){
			callback("Data not inserted",null);
		}
		else{
			callback(null,keyDoc);
		}
	});
};

var mongo = require('./mongoConnection');

//query variable contains json data used for querying the db

exports.findOne = function (collectionName,searchQuery,projectionQuery ,callback) {
	console.log("___dbname: "+collectionName+"___searchquery: "+JSON.stringify(searchQuery) +"___projectionQuery: "+JSON.stringify(projectionQuery));
	mongo.collection(collectionName).findOne(searchQuery, projectionQuery,function(err, keyDoc){
		if(err){
			//console.log(err);
			callback(err,"DB connectivity failed");
			}
		if(keyDoc==null||keyDoc==""){
			callback("Data not exists",null);
		}
		else{
			//console.log(keyDoc)
			callback(null,keyDoc);
		}
	});
};

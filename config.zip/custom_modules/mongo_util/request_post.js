var request = require("request");
exports.requestHttp = function (hostIp,port,url,data,filename,callback) {
	//console.log("fileName+++++++",stream);
	//console.log("____port : "+port+" : hostIp : " +hostIp+ " : pathurl : "+url+"fileName :"+filename);
		var finalurl="http://"+hostIp+'/'+url;
		console.log("finalurl",finalurl);
		var requ = request.post(finalurl, function (err, resp, body) {
			  if (err) {
			    console.log('Error!');
			  } else {
			 //   console.log('URL: ' + body);
			    callback(200,body);
			  }
			});
			var form = requ.form();
			form.append('file', data, {
			  filename: filename,
			  contentType: 'text/plain'
			});
};
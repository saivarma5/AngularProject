 const mongoose= require('mongoose');
 mongoose.connect('mongodb://localhost:27017/CrudDB', (err) =>{

if(!err)
console.log('MongoDB connection succeded.');
else
console.log('Error in DB Connection'+JSON.stringify(err,undefinedm,2));

 });

 module.exports=mongoose;
ip = require('ip');

console.log(ip.address());
